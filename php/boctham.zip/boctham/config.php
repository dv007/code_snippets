<?php
$config['db'] = array(
	'host' => 'localhost',
	'dbname' => 'boctham',
	'user' => 'root',
	'password' => '',
	'port' => 3306,
);

$config['num_result'] = 1;
$config['num_img'] = 20;